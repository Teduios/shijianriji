//
//  LCEDiary.m
//  iTimerDiary
//
//  Created by tarena on 15/12/22.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LCEDiary.h"

@implementation LCEDiary

@end
