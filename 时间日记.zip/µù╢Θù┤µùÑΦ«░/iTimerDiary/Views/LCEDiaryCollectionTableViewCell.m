//
//  LCEDiaryCollectionTableViewCell.m
//  iTimerDiary
//
//  Created by tarena on 15/12/22.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LCEDiaryCollectionTableViewCell.h"

@interface LCEDiaryCollectionTableViewCell() 




@end

@implementation LCEDiaryCollectionTableViewCell

- (void)awakeFromNib {
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
