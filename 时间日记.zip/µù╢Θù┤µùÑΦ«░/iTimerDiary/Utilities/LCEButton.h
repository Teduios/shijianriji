//
//  LCEButton.h
//  iTimerDiary
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCEButton : UIButton
@property (nonatomic, assign) NSInteger flag;
@property (nonatomic, assign) NSInteger indexPath;
@end
